let dino_y = 0
let cactus_x = 0
let strat = true
let new_score = false
let score = 0

var character = document.getElementById("character");
var cactus = document.querySelector('#block');
var new_score_block = document.querySelector('#new_score');
document.addEventListener ("click",  jump);

function jump () {

    dino_y = 100
    character.classList.add("animate");
    if (cactus_x > -80 && cactus_x < 120) {
        new_score_block.classList.add("see");     
        score += 50
        document.querySelector('#all_score').innerHTML= score;
    }
    setTimeout(removeJump, 700); // 300мс = длина анимации
    setTimeout(()=> {dino_y=0}, 800)
};
function removeJump () {

    character.classList.remove("animate");
    // if (cactus_x > -20 && cactus_x < 50) {
        new_score_block.classList.remove("see");
    // }
}
cactus.style.left = 500
cactus_x = 500
console.log(cactus_x)
let gogogog = setInterval(()=>{
    cactus_x-=1;
    cactus.style.left = cactus_x;
    if (cactus_x<-200) {
        cactus_x = 500 
    }
    if (cactus_x > -20 && cactus_x < 50 & dino_y!=100) {
        console.log("Looser")   
        strat = false
        clearInterval(gogogog);   
        window.parent.postMessage({ 
            "event_type": "game_run_end",
            "score": score 
        }, '*');  
    }
},1)